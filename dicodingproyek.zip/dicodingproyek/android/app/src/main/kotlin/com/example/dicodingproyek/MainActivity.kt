package com.example.dicodingproyek

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
